from django.contrib import admin
from .models import *

admin.site.register(Student)
admin.site.register(Booking)
admin.site.register(Profile)
admin.site.register(ExamType)



# Register your models here.
