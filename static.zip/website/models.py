from django.db import models

#model for student
class Student(models.Model):
    create_at = models.DateTimeField(auto_now_add=True)
    username = models.CharField(max_length=50)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    phone = models.CharField(max_length=15)
    address = models.CharField(max_length=100)

    def __str__(self):
        return f"Student->{self.first_nmae}"

#model for booking(form details)  
class Booking(models.Model):
    name = models.CharField(max_length=100)
    passport = models.CharField(max_length=100)
    exam_date = models.DateField()
    test_city = models.CharField(max_length=100)
    signature = models.FileField(upload_to='signatures/')
    signature_date = models.DateField()
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    test_model = models.CharField(max_length=20, choices=[('academic', 'Academic'), ('general', 'General Training')])
    delivery_method = models.CharField(max_length=20, choices=[('computer', 'Computer-delivered'), ('paper', 'Paper-based')])

    def __str__(self):
        return f"Booking ->{self.name}" 
    

class Profile(models.Model):
    full_name = models.CharField(max_length=100)
    profile_image = models.ImageField(upload_to='profile_images/')
    email = models.EmailField()
    phone_number = models.CharField(max_length=15)
    date_of_birth = models.DateField()
    address = models.TextField()
    student_id = models.CharField(max_length=20)
    course = models.CharField(max_length=100)
    batch = models.CharField(max_length=20)
    major = models.CharField(max_length=100)

def __str__(self):
        return f"Profile ->{self.name}" 

#Exam Tyes 
class ExamType(models.Model):
    TEST_TYPE_CHOICES = [
        ('paper', 'IELTS on Paper'),
        ('computer', 'IELTS on Computer'),
        ('visa', 'IELTS for Visas and Immigration'),
        ('lifeskill', 'IELTS Life Skills'),
    ]
    TEST_MODEL_CHOICES = [
        ('academic', 'Academic'),
        ('general', 'General Training'),
    ]

    city_name = models.CharField(max_length=100)
    location = models.CharField(max_length=200)
    current_fee = models.IntegerField()
    newest_fee = models.IntegerField()
    test_type = models.CharField(max_length=20, choices=TEST_TYPE_CHOICES)
    test_model = models.CharField(max_length=20, choices=TEST_MODEL_CHOICES)

    def __str__(self):
        return f"{self.get_test_type_display()} - {self.test_model} - {self.city_name}"
    def __str__(self):
        return f"{self.city_name} ExamType"



#model for partner
# class Partner(models.Model):
#     create_at = models.DateTimeField(auto_now_add=True)
#     username = models.CharField(max_length=50)
#     first_name = models.CharField(max_length=50)
#     last_name = models.CharField(max_length=50)
#     email = models.CharField(max_length=50)
#     phone = models.CharField(max_length=15)
#     address = models.CharField(max_length=100)
#     pdf_file = models.FileField(upload_to='pdfs/')

   
class Blank(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name